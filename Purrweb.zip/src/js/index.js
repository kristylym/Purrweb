import "./import/modules";
import "./import/smooth-scroll.polyfills";
import SmoothScroll from 'smooth-scroll'
let Swiper = require('./import/swiper.min.js')
let swiper = new Swiper('.swiper-container', {
    direction: 'vertical',
    pagination: {
      el: '.swiper-pagination',
      clickable: true,
    },
  });

  var scroll = new SmoothScroll('a[href*="#"]');
  

